<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Set a unique slug-like ID
//
$prefix = '_agency_my_options';

//
// Create options
//
CSF::createOptions( $prefix, array(
  'menu_title' => 'Agency Option',
  'menu_slug'  => 'agency-demo',
) );

//
// Create a section
//
CSF::createSection( $prefix, array(
  'title'  => 'Header Option',
  'icon'   => 'fas fa-rocket',
  'fields' => array(

    //
    // Header Email
    //
    array(
      'id'    => 'header-email',
      'type'  => 'text',
      'title' => 'Email',
      'desc'  => 'Add Email',
      'default' => 'demo@gmail.com',
    ),

     //
    // Header Number
    //
    array(
      'id'    => 'header-number',
      'type'  => 'number',
      'title' => 'Number',
      'desc'  => 'Add Number',
      'default' => '01319628008',
    ),


     //
    // Header Social
    //

    array(
      'id'        => 'header-social',
      'type'      => 'group',
      'title'     => 'Add Social ',
      'fields'    => array(
        array(
          'id'    => 'social-icon',
          'type'  => 'icon',
          'title' => 'Add Social Icon',
          'desc'  => 'Add Social Icon',
        ),
        array(
          'id'    => 'social-link',
          'type'  => 'text',
          'title' => 'Add Link',
          'desc'  => 'Add Social Link',
        ),
      ),
      'default'   => array(
        array(
          'social-icon'     => 'fab fa-facebook-f',
          'social-link'     => array(
            'url'    => 'https://facebook.com',
          ),
        ),
        array(
          'social-icon'     => 'fab fa-twitter',
          'social-link'     => array(
            'url'    => 'https://twitter.com',
          ),
        ),
        array(
          'social-icon'     => 'fab fa-linkedin',
          'social-link'     => array(
            'url'    => 'https://linkedin.com',
          ),
        ),
        array(
          'social-icon'     => 'fab fa-youtube',
          'social-link'     => array(
            'url'    => 'https://youtube.com',
          ),
        ),
        array(
          'social-icon'     => 'fab fa-google-plus-g',
          'social-link'     => array(
            'url'    => 'https://google.com',
          ),
        ),

      ),
    ),


    //
    // Header Social
    //

    array(
      'id'    => 'header-bg',
      'type'  => 'color',
      'title' => 'Heder top bar background',
      'desc'  => 'Add background colour',
      'default' => '#635CDB',
    ),

  )
) );
CSF::createSection( $prefix, array(
  'title'  => 'About  Option',
  'icon'   => 'fas fa-rocket',
  'fields' => array(

    //
    // About Header Section
    //
    array(
      'id'    => 'abt-header-section',
      'type' => 'fieldset',
      'title' => 'About Header Section',
      'fields' => array(
            array(
              'id'    => 'abt-header-title',
              'type'  => 'text',
              'title' => 'Header  Title',
              'desc'  => 'Write a title',
              'default' => 'who we are?',
            ),
            array(
              'id'    => 'abt-header-subtitle',
              'type'  => 'text',
              'title' => 'Header   Subtitle',
              'desc'  => 'Write a subtitle',
              'default' => 'About Us',
            ),
            array(
              'id'    => 'abt-header-des',
              'type'  => 'textarea',
              'title' => 'Header   Description',
              'desc'  => 'Write a description',
              'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry. ',
            ),

          )),
    //
    // About Content
    //
    array(
      'id'    => 'abt-header-content',
      'type' => 'fieldset',
      'title' => 'About Header Section',
      'fields' => array(
            array(
              'id'    => 'abt-content-title',
              'type'  => 'text',
              'title' => 'About Title',
              'desc'  => 'Add About Title',
              'default' => 'Welcome to agency',
            ),
            array(
              'id'    => 'abt-content-des',
              'type'  => 'code_editor',
              'title' => 'About Content',
              'desc'  => 'Add About Content',
              'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the ',
            ),
            array(
              'id'    => 'abt-content-btn',
              'type'  => 'text',
              'title' => 'Button Text',
              'desc'  => 'Add Button Text',
              'default' => 'Read More',
            ),
            array(
              'id'    => 'abt-content-url',
              'type'  => 'text',
              'title' => 'Button URL',
              'desc'  => 'Add Button URL',
              'default' => '#',
            ),

          )),
    //
    // About Feature
    //
    array(
      'id'    => 'abt-header-feature',
      'type' => 'group',
      'title' => 'About Features',
      'fields' => array(
            array(
              'id'    => 'abt-feature-title',
              'type'  => 'text',
              'title' => 'Featuer Title',
              'desc'  => 'Add Featuer Title',
            ),
            array(
              'id'    => 'abt-feature-des',
              'type'  => 'textarea',
              'title' => 'Feature Content',
              'desc'  => 'Add Feature Content',
            ),
            array(
              'id'    => 'abt-feature-icon',
              'type'  => 'icon',
              'title' => 'Icon',
              'desc'  => 'Add Icon',
            ),

          ),
          'default'   => array(
            array(
              'abt-feature-title'     => 'our mission',
              'abt-feature-des'     => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry',
              'abt-feature-icon'     => 'fas fa-tv',
            ),
            array(
              'abt-feature-title'     => 'our vission',
              'abt-feature-des'     => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry',
              'abt-feature-icon'     => 'fas fa-user',
            ),
            array(
              'abt-feature-title'     => 'our history',
              'abt-feature-des'     => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry',
              'abt-feature-icon'     => 'fas fa-pencil-alt',
            ),
            ),
    
          ),
        
        
       
) ));


    //
    // Services Header Section
    //

    CSF::createSection( $prefix, array(
      'title'  => 'Services Option',
      'icon'   => 'fas fa-rocket',
      'fields' => array(
    array(
      'id'    => 'serv-header-section',
      'type' => 'fieldset',
      'title' => 'Services Header Section',
      'fields' => array(
            array(
              'id'    => 'serv-header-title',
              'type'  => 'text',
              'title' => 'Header  Title',
              'desc'  => 'Write a title',
              'default' => 'our services',
            ),
            array(
              'id'    => 'serv-header-subtitle',
              'type'  => 'text',
              'title' => 'Header   Subtitle',
              'desc'  => 'Write a subtitle',
              'default' => 'who we are?',
            ),
            array(
              'id'    => 'serv-header-des',
              'type'  => 'textarea',
              'title' => 'Header   Description',
              'desc'  => 'Write a description',
              'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.',
            ),

          )),
        )));

        
    //
    // Team Header Section
    //

    CSF::createSection( $prefix, array(
      'title'  => 'Team Option',
      'icon'   => 'fas fa-rocket',
      'fields' => array(
    array(
      'id'    => 'team-header-section',
      'type' => 'fieldset',
      'title' => 'Team Header Section',
      'fields' => array(
            array(
              'id'    => 'team-header-title',
              'type'  => 'text',
              'title' => 'Header  Title',
              'desc'  => 'Write a title',
              'default' => 'creative team',
            ),
            array(
              'id'    => 'team-header-subtitle',
              'type'  => 'text',
              'title' => 'Header   Subtitle',
              'desc'  => 'Write a subtitle',
              'default' => 'who we are?',
            ),
            array(
              'id'    => 'team-header-des',
              'type'  => 'textarea',
              'title' => 'Header   Description',
              'desc'  => 'Write a description',
              'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.',
            ),

          )),
        )));


         //
    // Testimonial Header Section
    //

    CSF::createSection( $prefix, array(
      'title'  => 'Testimonial Option',
      'icon'   => 'fas fa-rocket',
      'fields' => array(
    array(
      'id'    => 'testimonial-header-section',
      'type' => 'fieldset',
      'title' => 'Testimonial Header Section',
      'fields' => array(
            array(
              'id'    => 'testimonial-header-title',
              'type'  => 'text',
              'title' => 'Header  Title',
              'desc'  => 'Write a title',
              'default' => 'what client say',
            ),
            array(
              'id'    => 'testimonial-header-subtitle',
              'type'  => 'text',
              'title' => 'Header   Subtitle',
              'desc'  => 'Write a subtitle',
              'default' => 'who we are?',
            ),
            array(
              'id'    => 'testimonial-header-des',
              'type'  => 'textarea',
              'title' => 'Header   Description',
              'desc'  => 'Write a description',
              'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.',
            ),

          )),
        )));

     //
    // Latest News Optins
    //

    CSF::createSection( $prefix, array(
      'title'  => 'News Option',
      'icon'   => 'fas fa-rocket',
      'fields' => array(
    array(
      'id'    => 'news-header-section',
      'type' => 'fieldset',
      'title' => 'News Header Section',
      'fields' => array(
            array(
              'id'    => 'news-header-title',
              'type'  => 'text',
              'title' => 'Header  Title',
              'desc'  => 'Write a title',
              'default' => 'latest news',
            ),
            array(
              'id'    => 'news-header-subtitle',
              'type'  => 'text',
              'title' => 'Header   Subtitle',
              'desc'  => 'Write a subtitle',
              'default' => 'who we are?',
            ),
            array(
              'id'    => 'news-header-des',
              'type'  => 'textarea',
              'title' => 'Header   Description',
              'desc'  => 'Write a description',
              'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.',
            ),

          )),
        )));

        

    //
    // FAQ
    //

CSF::createSection( $prefix, array(
  'title'  => 'Faq Option',
  'icon'   => 'fas fa-rocket',
  'fields' => array(

    array(
      'id'    => 'faq-section-title',
      'type'  => 'text',
      'title' => 'FAQ Section Title',
      'desc'  => 'Add FAQ Section Title',
      'default' => 'FAQ',
    ),

    array(
      'id'    => 'faq-option',
      'type' => 'group',
      'title' => 'About Features',
      'fields' => array(
            array(
              'id'    => 'faq-title',
              'type'  => 'text',
              'title' => 'FAQ Title',
              'desc'  => 'Add FAQ Title',
            ),
            array(
              'id'    => 'faq-des',
              'type'  => 'textarea',
              'title' => 'FAQ Description',
              'desc'  => 'Add FAQ Description',
            ),

          ),
          'default'   => array(
            array(
              'faq-title'     => 'Anim pariatur cliche reprehenderit',
              'faq-des'     => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. ',
            ),
            array(
              'faq-title'     => 'Anim pariatur cliche reprehenderit',
              'faq-des'     => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. ',
            ),
            array(
              'faq-title'     => 'Anim pariatur cliche reprehenderit',
              'faq-des'     => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. ',
            ),

            ),
        
        
        
        ),

  )));

      //
      // Skill
      //
  CSF::createSection( $prefix, array(
    'title'  => 'Skill Options',
    'icon'   => 'fas fa-rocket',
    'fields' => array(
  
  
      array(
        'id'    => 'skill-section-title',
        'type'  => 'text',
        'title' => 'skill Section Title',
        'desc'  => 'Add skill Section Title',
        'default' => 'Our Skill',
      ),
  
      array(
        'id'    => 'skill-option',
        'type' => 'group',
        'title' => 'About Features',
        'fields' => array(
              array(
                'id'    => 'skill-title',
                'type'  => 'text',
                'title' => 'skill Title',
                'desc'  => 'Add skill Title',
              ),
              array(
                'id'    => 'skill-percentage',
                'type'  => 'number',
                'title' => 'skill percentage',
                'desc'  => 'Add skill percentage',
              ),
  
            ),
            'default'   => array(
              array(
                'skill-title'     => 'html',
                'skill-percentage'     => '90',
              ),
              array(
                'skill-title'     => 'Css',
                'skill-percentage'     => '80',
              ),
              array(
                'skill-title'     => 'Bootstrap',
                'skill-percentage'     => '75',
              ),
              array(
                'skill-title'     => 'Jquery',
                'skill-percentage'     => '80',
              ),
              array(
                'skill-title'     => 'wordpress',
                'skill-percentage'     => '90',
              ),

  
              ),
          
          
          ),
  
    )));


      //
      // CTA Option
      //
      CSF::createSection( $prefix, array(
        'title'  => 'CTA Options',
        'icon'   => 'fas fa-rocket',
        'fields' => array(
      
                array(
                  'id'    => 'cat-title',
                  'type'  => 'text',
                  'title' => 'Add CTA Title',
                  'default' => 'best solution for your business ',
                ),
                array(
                  'id'    => 'cat-subtitle',
                  'type'  => 'textarea',
                  'title' => 'Add CTA Subtitle',
                  'default' => 'the can be used on larger scale projectss as well as small scale projectss',
                ),
                array(
                  'id'    => 'cat-btn-text',
                  'type'  => 'text',
                  'title' => 'Add CTA Button Text',
                  'default' => 'Contact Us',
                ),
                array(
                  'id'    => 'cat-btn-link',
                  'type'  => 'link',
                  'title' => 'Add CTA Button Link',
                  'default'  => array(
                    'url'    => '#',
                  ),
                ),
      
        )));

      //
      // Contact
      //
      CSF::createSection( $prefix, array(
        'title'  => 'Contact Options',
        'icon'   => 'fas fa-rocket',
        'fields' => array(
      
      
          array(
            'id'    => 'contact-option',
            'type' => 'group',
            'title' => 'Contact Features',
            'fields' => array(
                  array(
                    'id'    => 'contact-icon',
                    'type'  => 'icon',
                    'title' => 'contact Icon',
                    'desc'  => 'Add contact Icon',
                  ),
                  array(
                    'id'    => 'contact-title',
                    'type'  => 'text',
                    'title' => 'contact Title',
                    'desc'  => 'Add contact title',
                  ),
                  array(
                    'id'    => 'contact-info',
                    'type'  => 'text',
                    'title' => 'contact Info',
                    'desc'  => 'Add contact info',
                  ),
      
                ),
                'default'   => array(
                  array(
                    'contact-icon'     => 'fas fa-envelope',
                    'contact-title'     => 'Email',
                    'contact-info'     => 'demo@gmail.com',
                  ),
                  array(
                    'contact-icon'     => 'fas fa-phone-alt',
                    'contact-title'     => 'Number ',
                    'contact-info'     => '000 123 456 789',
                  ),
                  array(
                    'contact-icon'     => 'fas fa-envelope',
                    'contact-title'     => 'Location ',
                    'contact-info'     => 'Dashpaha,Sylhet',
                  ),
      
                  ),
              
              
              ),

                array(
                  'id'    => 'contact-map',
                  'type'  => 'map',
                  'title' => 'Add Map',
                  'default'     => array(
                    'address'   => 'New York, United States of America',
                    'latitude'  => '40.7127281',
                    'longitude' => '-74.0060152',
                    'zoom'      => '12',
                  )

                ),
      
        )));
    

         //
      // Footer Option
      //
      CSF::createSection( $prefix, array(
        'title'  => 'Footer Options',
        'icon'   => 'fas fa-rocket',
        'fields' => array(
      
      
          array(
            'id'    => 'footer-option',
            'type' => 'group',
            'title' => 'Footer Features',
            'fields' => array(
                  array(
                    'id'    => 'footer-icon',
                    'type'  => 'icon',
                    'title' => 'Footer Icon',
                    'desc'  => 'Add Footer Icon',
                  ),
                  array(
                    'id'    => 'footer-link',
                    'type'  => 'link',
                    'title' => 'Footer Link',
                    'desc'  => 'Add Footer title',
                  ),
  
                ),
                'default'   => array(
                  array(
                    'footer-icon'     => 'fab fa-facebook-f',
                    'footer-link'     => array(
                      'url'    => 'https://facebook.com',
                    ),
                  ),
                  array(
                    'footer-icon'     => 'fab fa-twitter',
                    'footer-link'     => array(
                      'url'    => 'https://twitter.com',
                    ),
                  ),
                  array(
                    'footer-icon'     => 'fab fa-linkedin',
                    'footer-link'     => array(
                      'url'    => 'https://linkedin.com',
                    ),
                  ),
                  array(
                    'footer-icon'     => 'fab fa-youtube',
                    'footer-link'     => array(
                      'url'    => 'https://youtube.com',
                    ),
                  ),
                  array(
                    'footer-icon'     => 'fab fa-google-plus-g',
                    'footer-link'     => array(
                      'url'    => 'https://google.com',
                    ),
                  ),

                ),

              ),

                array(
                  'id'    => 'footer-copyright',
                  'type'  => 'text',
                  'title' => 'Add Copyright',
                  'default' => '© All Rights Reserved 2022'
                ),
      
        )));
    