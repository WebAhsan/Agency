<?php 


require_once get_template_directory(). '/inc/class-tgm-plugin-activation.php';


function agency_plugin_activatin(){

    $plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Advanced Custom Fields', // The plugin name.
			'slug'               => 'advanced-custom-fields', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'codestarframework', // The plugin name.
			'slug'               => 'codestar-framework', // The plugin slug (typically the folder name).
            'source'   => 'https://github.com/Codestar/codestar-framework/archive/refs/heads/master.zip',
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'Contact Form 7', // The plugin name.
			'slug'               => 'contact-form-7', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'One Click Demo Import', // The plugin name.
			'slug'               => 'one-click-demo-import', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'Advanced Custom Fields: Font Awesome Field', // The plugin name.
			'slug'               => 'advanced-custom-fields-font-awesome', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
		
		// <snip />
	);
    $config = array(
        'id'           => 'agency_plugin_activation',                 // Unique ID for hashing notices for multiple instances of TGMPA.                 // Default absolute path to bundled plugins.
        'menu'         => 'agency-plugin-activation', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
    );
    tgmpa( $plugins, $config );

   

}

add_action( 'tgmpa_register', 'agency_plugin_activatin' );



